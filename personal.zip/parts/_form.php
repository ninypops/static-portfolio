<form >
    <input type="text" placeholder="name" name="name">
    <input type="email" placeholder="email" name="email">
    <select name="enquiry">
        <option value="contract work">contract work</option>
        <option value="freelance work">freelance work</option>
        <option value="hiring">hiring</option>
        <option value=""></option>
    </select>
    <input type="submit" value="Submit">
</form>