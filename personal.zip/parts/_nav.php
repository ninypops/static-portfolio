<!-- <div class="menu-btn"><i class="fa fa-bars"></i> Menu</div> -->
<ul class="navigation container">
    <li><a href="./" tab-index="1" title="homepage">Home</a></li>
    <!-- <li><a href="/assets/pdfs/NLimbrick-2019-Resume" download target="_blank">Resume</a></li> -->
    <li><a href="portfolio.php" tab-index="2" title="portfolio">Portfolio</a></li>
</ul>