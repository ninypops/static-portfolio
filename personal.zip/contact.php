<!DOCTYPE html>
<html lang="en-US">
<head>
    <?php include('parts/_head.php'); ?>
    <?php include('parts/_nav.php');?>
</head>

<body>
<?php include('parts/_mobile-nav.php');?>
    <main>
        <section class=" fadeIn">
          
        </section>
    </main>

<footer>
</footer>

</body>
</html>